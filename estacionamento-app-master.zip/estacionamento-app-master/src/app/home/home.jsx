import Navbar from "@/components/Navbar/content";

export function Home () {
    return 
}