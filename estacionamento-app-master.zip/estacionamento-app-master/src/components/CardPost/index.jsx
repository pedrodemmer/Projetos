export const CardPost = ({ post }) => {
    return (
        <article>
            <header>
                <figure>

                </figure>
            </header>
            <section>
                titulo
                texto
            </section>
            <footer>

            </footer>
        </article>
    );
};
