export default function Table () {
    return (
        <div>
            
        </div>
    )
}